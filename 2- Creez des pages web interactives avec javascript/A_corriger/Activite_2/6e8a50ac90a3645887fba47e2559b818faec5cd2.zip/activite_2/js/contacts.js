/*
Activité : gestion des contacts
*/

// TODO : complétez le programme

var Contact = {
  init: function(nom, prenom){
    this.nom = nom;//prompt("Entrez le nom du nouveau contact :");
    this.prenom = prenom;//prompt("Entrez le prénom du nouveau contact :");
  },

  decrire: function(){
    var description = "Nom : " + this.nom + ", prénom : " + this.prenom;
    return description;
  }
};

var contact1 = Object.create(Contact);
contact1.init ("Lévisse", "Carole");

var contact2 = Object.create(Contact);
contact2.init ("Nelsonne", "Mélodie");


var contacts = [contact1, contact2];
/*contacts.push(contact1);
contacts.push(contact2);*/


console.log("Bienvenue dans le gestionnaire de contacts !");
console.log(1 + " : Lister les contacts");
console.log(2 + " : Ajouter un contact");
console.log(0 + " : Quitter");


var option = Number(prompt("Choisissez une option :"));

while ((option===1)||(option===2)) {

  switch (option) {
    case 1:
        console.log();
        console.log("Voici la liste de tous vos contacts :");
        contacts.forEach(function (contact){
          console.log(contact.decrire());
      });
        console.log();
        console.log(1 + " : Lister les contacts");
        console.log(2 + " : Ajouter un contact");
        console.log(0 + " : Quitter");
        break;
    case 2:
        var contactnew = Object.create(Contact);
        contactnew.init (prompt("Entrez le nom du nouveau contact :"), prompt("Entrez le prénom du nouveau contact :"));
        contacts.push(contactnew);
        console.log("Le nouveau contact a été ajouté");
        break;
  }
  option = Number(prompt("Choisissez une option :"));
}if (option===0) {
  console.log();
  console.log("Au revoir !");
}



















/*
var Film = {

  init: function (titre, annee, realisateur){
    this.titre = prompt("Entrez un titre de film: ");
    this.annee = Number(prompt("Entrez son année de sortie: "));
    this.realisateur = prompt("Entrez son réalisateur: ");
  },
  decrire: function (){
    var description = this.titre + " (" + this.annee + ", " + this.realisateur + ") ";
    return description;
  }
};

var film1 = Object.create(Film);
film1.init(this.titre, this.annee, this.ralisateur);

var film2 = Object.create(Film);
film2.init(this.titre, this.annee, this.ralisateur);

var film3 = Object.create(Film);
film3.init(this.titre, this.annee, this.ralisateur);

var Films = [film1, film2, film3];

Films.forEach (function (film) {
  console.log(film.decrire());
});
*/
